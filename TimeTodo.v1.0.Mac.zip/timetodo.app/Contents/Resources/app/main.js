const electron = require('electron');
const storage = require('electron-json-storage');
const { app } = electron;  // Module to control application life.
const { BrowserWindow }  = electron;  
const { ipcMain } = electron;

let  win;

ipcMain.on('timetodo-msg', (event, arg) => 
{
    if( arg == 'close' ) app.quit();
    event.returnValue = 'do close';
})

ipcMain.on('timetodo-command', (event, arg) => 
{
    eval(arg);
    event.returnValue = 'do command';
})


function createWindow()
{
    win = new BrowserWindow( { width:320,height:450,titleBarStyle: 'hiddenInset',transparent: true,hasShadow:false,fullscreenable:false } );
    win.loadURL( `file://${__dirname}/index.html` );
    win.setAlwaysOnTop(true, "floating", 1);
    
    win.on( 'close' , ()=> win=null );
    
}


app.on( 'ready' , createWindow );
app.on('window-all-closed', () => {
    app.quit()
})